import json
import os

from dotenv import load_dotenv
from lambda_utils import base_lambda_handler

load_dotenv()


OPENSEARCH_USER = os.getenv("OPENSEARCH_USER")
OPENSEARCH_PASSWORD = os.getenv("OPENSEARCH_PASSWORD")
OPENSEARCH_HOST = os.getenv("OPENSEARCH_HOST")

STATUS_INDEX = "npgw.transaction.status"


def lambda_handler_status(event, context):
    """
    Handler for status index. Overrides old transaction versions
    doc ID = transactionId
    """
    def doc_id_builder(doc):
        return doc.get("transactionId")

    return base_lambda_handler(
        event,
        context,
        doc_id_builder,
        OPENSEARCH_HOST,
        OPENSEARCH_USER,
        OPENSEARCH_PASSWORD,
        STATUS_INDEX
    )