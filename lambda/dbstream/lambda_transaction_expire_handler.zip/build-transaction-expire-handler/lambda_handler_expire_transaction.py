import os
import json
import boto3
from datetime import datetime, timezone
from boto3.dynamodb.conditions import Attr
from dotenv import load_dotenv
from lambda_utils import _boto3_kwargs

load_dotenv()


dynamodb = boto3.resource(
    "dynamodb", **_boto3_kwargs()
)

transaction_table = dynamodb.Table("npgw.transaction")
NON_TERMINAL_STATUSES = {"Initiated", "Pending"}


def _utc_now_iso() -> str:
    """Return current UTC time in ISO format with milliseconds and trailing Z."""
    return (
        datetime.utcnow().replace(tzinfo=timezone.utc)
        .isoformat(timespec="milliseconds")
        .replace("+00:00", "Z")
    )


def lambda_handler_expire_transaction(event, context):
    """
    Lambda triggered by EventBridge schedule. Expects payload: {"transactionId": "..."}
    It sets transaction status to EXPIRED **only if** transaction is still non-terminal.
    """

    transaction_id = event.get("transactionId")
    if not transaction_id:
        print("No transactionId provided in event: %s" % json.dumps(event))
        return {"statusCode": 400, "body": "transactionId missing"}

    try:
        resp = transaction_table.get_item(Key={"transactionId": transaction_id})
        item = resp.get("Item")
        if not item:
            print(f"Transaction {transaction_id} not found, nothing to update")
            return {"statusCode": 200}

        current_status = item.get("status")
        if current_status not in NON_TERMINAL_STATUSES:
            print(
                f"Transaction {transaction_id} already in terminal status '{current_status}', no action taken"
            )
            return {"statusCode": 200}

        now_iso = _utc_now_iso()
        transaction_table.update_item(
            Key={"transactionId": transaction_id},
            UpdateExpression="SET #s = :newStatus, updatedOn = :updatedOn",
            ConditionExpression=Attr("status").is_in(NON_TERMINAL_STATUSES),
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={":newStatus": "Expired", ":updatedOn": now_iso},
        )
        print(f"Transaction {transaction_id} marked as Expired at {now_iso}")
        return {"statusCode": 200}

    except dynamodb.meta.client.exceptions.ConditionalCheckFailedException:
        # Status changed between read and update
        print(
            f"Conditional update failed for {transaction_id}, status changed concurrently"
        )
        return {"statusCode": 200}
    except Exception as e:
        print(f"Unexpected error processing {transaction_id}: {e}")
        return {"statusCode": 500, "body": str(e)} 