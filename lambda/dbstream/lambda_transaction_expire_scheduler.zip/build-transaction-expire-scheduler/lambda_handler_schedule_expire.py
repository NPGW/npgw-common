import os
import json
import boto3
from datetime import datetime, timezone
from dotenv import load_dotenv
from lambda_utils import _boto3_kwargs

load_dotenv()


sns_client       = boto3.client("sns",       **_boto3_kwargs())
scheduler_client = boto3.client("scheduler", **_boto3_kwargs())
lambda_client    = boto3.client("lambda",    **_boto3_kwargs())

EXPIRE_LAMBDA_NAME = os.getenv("EXPIRE_LAMBDA_NAME", "TransactionExpireHandler")
EXPIRE_LAMBDA_ARN = f"arn:aws:lambda:eu-central-1:000000000000:function:{EXPIRE_LAMBDA_NAME}"


LAMBDA_HANDLER_EXPIRE_ROLE_ARN = os.getenv(
    "LAMBDA_HANDLER_EXPIRE_ROLE_ARN", "arn:aws:iam::000000000000:role/lambda-role"
)


def _sanitize_transaction_id(tx_id: str) -> str:
    """Cut the transaction id so that the resulting rule name fits in 64 chars."""
    if len(tx_id) <= 40:
        return tx_id
    return tx_id[:40]


def _build_at_expression(iso_ts: str) -> str:
    """Convert ISO timestamp to EventBridge `at()` expression."""
    if iso_ts.endswith("Z"):
        iso_ts = iso_ts[:-1]
    if '.' in iso_ts:
        dt_part, frac = iso_ts.split('.')
        frac = frac[:6]  # keep only microseconds
        iso_ts = f"{dt_part}.{frac}"
    dt = datetime.fromisoformat(iso_ts)
    ts_no_tz = dt.replace(tzinfo=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
    return f"at({ts_no_tz})"


def _get_inner_sns_message(raw_msg: str):
    """Unwrap SNS message whether MessageStructure=json was used or not."""
    try:
        parsed = json.loads(raw_msg)
        if "transactionId" not in parsed and "default" in parsed:
            parsed = json.loads(parsed["default"])
        return parsed
    except json.JSONDecodeError:
        return {}


def lambda_handler_schedule_expire(event, context):
    """
    Lambda triggered by SNS topic `dynamodb-events`. For each INITIATED transaction it creates
    an EventBridge rule that will fire at `expiresAt` timestamp, invoking
    `TransactionExpireHandler` lambda with the transactionId as payload.
    """

    records = event.get("Records", [])
    print(f"Received {len(records)} SNS record(s) for expiration scheduling")

    for sns_record in records:
        sns_msg_raw = sns_record.get("Sns", {}).get("Message", "{}")
        sns_msg = _get_inner_sns_message(sns_msg_raw)
        transaction_id = sns_msg.get("transactionId")
        dynamodb_event = sns_msg.get("dynamodbEvent", {})

        if not transaction_id or not dynamodb_event:
            print("Missing transactionId or dynamodbEvent in SNS message, skipping")
            continue

        new_img = (dynamodb_event.get("dynamodb", {}).get("NewImage", {}) if dynamodb_event else {})
        status = new_img.get("status", {}).get("S") if new_img else None

        if status != "Initiated":
            print(f"Transaction {transaction_id} status '{status}', no scheduling required")
            continue

        expired_at_iso = new_img.get("expiresAt", {}).get("S") if new_img else None
        if not expired_at_iso:
            print(f"Transaction {transaction_id} has no expiresAt field, skipping")
            continue

        try:
            schedule_at = _build_at_expression(expired_at_iso)
        except Exception as e:
            print(f"Failed to build schedule expression from '{expired_at_iso}': {e}")
            continue

        rule_name = f"schedule-expire-{_sanitize_transaction_id(transaction_id)}"

        try:
            schedule_response = scheduler_client.create_schedule(
                Name=rule_name,
                ScheduleExpression=schedule_at,
                ScheduleExpressionTimezone="UTC",
                FlexibleTimeWindow={"Mode": "OFF"},
                State="ENABLED",
                Target={
                    "Arn": EXPIRE_LAMBDA_ARN,
                    "Input": json.dumps({"transactionId": transaction_id}),
                    "RoleArn": LAMBDA_HANDLER_EXPIRE_ROLE_ARN,
                },
            )

            schedule_arn = schedule_response["ScheduleArn"]

            # Grant permission for EventBridge Scheduler to invoke the lambda (ignore if exists)
            try:
                lambda_client.add_permission(
                    FunctionName=EXPIRE_LAMBDA_NAME,
                    StatementId="scheduler",
                    Action="lambda:InvokeFunction",
                    Principal="events.amazonaws.com",
                    SourceArn=schedule_arn,
                )
            except lambda_client.exceptions.ResourceConflictException:
                pass

            print(f"Expiration scheduled for {transaction_id} at {schedule_at}")

        except Exception as e:
            print(
                f"Error creating schedule for transaction {transaction_id} at {expired_at_iso}: {e}"
            )
            continue

    return {
        "statusCode": 200,
        "body": json.dumps("Processed scheduling events"),
    } 