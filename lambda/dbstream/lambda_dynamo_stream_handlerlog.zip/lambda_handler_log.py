import json
import os

from dotenv import load_dotenv
from lambda_utils import base_lambda_handler

load_dotenv()


OPENSEARCH_USER = os.getenv("OPENSEARCH_USER")
OPENSEARCH_PASSWORD = os.getenv("OPENSEARCH_PASSWORD")
OPENSEARCH_HOST = os.getenv("OPENSEARCH_HOST")

HISTORY_INDEX = "npgw.transaction.log"


def lambda_handler_log(event, context):
    """
    Handler for history index. Keeps all transaction versions
    doc ID = '{transactionId}-{updatedOn}'
    """

    def doc_id_builder(doc):
        transaction_id = doc.get("transactionId")
        updated_on = doc.get("updatedOn")
        return f"{transaction_id}-{updated_on}"

    return base_lambda_handler(
        event,
        context,
        doc_id_builder,
        OPENSEARCH_HOST,
        OPENSEARCH_USER,
        OPENSEARCH_PASSWORD,
        HISTORY_INDEX
    )
