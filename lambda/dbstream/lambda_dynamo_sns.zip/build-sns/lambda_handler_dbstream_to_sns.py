import json
import os
import boto3
from dotenv import load_dotenv
from lambda_utils import iso_to_int
from lambda_utils import _boto3_kwargs

load_dotenv()


SNS_TOPIC_ARN = os.getenv("SNS_TOPIC_ARN")

sns_client = boto3.client(
    "sns", **_boto3_kwargs()
)


def lambda_handler_dbstream_to_sns(event, context):
    """
    Lambda function that reads from dynamodb stream and pushes to SNS topic.
    
    Configuration:
    - batch_size = 1
    - reserved concurrency = 1
    
    Each SNS message contains:
    - dynamodb event
    - transactionId
    - update_on_nanoseconds
    """
    
    print(f"Processing {len(event.get('Records', []))} records from dynamodb stream")
    
    for record in event.get("Records", []):
        try:

            dd = record.get("dynamodb", {})
            new_img = dd.get("NewImage", {})
            old_img = dd.get("OldImage", {})

            if new_img and "transactionId" in new_img:
                if "S" in new_img["transactionId"]:
                    transaction_id = new_img["transactionId"]["S"]
            elif old_img and "transactionId" in old_img:
                if "S" in old_img["transactionId"]:
                    transaction_id = old_img["transactionId"]["S"]

            updated_on_timestamp = new_img["updatedOn"]["S"]
            update_on_nanoseconds = iso_to_int(updated_on_timestamp)

            sns_message = {
                "transactionId": transaction_id,
                "dynamodbEvent": record,
                "update_on_nanoseconds": update_on_nanoseconds
            }

            response = sns_client.publish(
                TopicArn=SNS_TOPIC_ARN,
                Message=json.dumps({"default": json.dumps(sns_message)}),
                Subject=f"Transaction Event - {record.get('eventName', 'UNKNOWN')}",
                MessageStructure="json"
            )
            
            print(f"Published message to SNS. MessageId: {response['MessageId']}, TransactionId: {transaction_id}")
            
        except Exception as e:
            print(f"Error processing record {record.get('eventID', 'unknown')}: {str(e)}")
            # TODO: send to DLQ or raise exception
            continue
    
    return {
        "statusCode": 200,
        "body": json.dumps(f"Processed {len(event.get('Records', []))} records")
    }
