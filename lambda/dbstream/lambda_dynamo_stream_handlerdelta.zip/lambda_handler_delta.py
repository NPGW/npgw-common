import json
import os

from dotenv import load_dotenv
from lambda_utils import custom_deserialize, make_bulk_request

load_dotenv()


OPENSEARCH_USER = os.getenv("OPENSEARCH_USER")
OPENSEARCH_PASSWORD = os.getenv("OPENSEARCH_PASSWORD")
OPENSEARCH_HOST = os.getenv("OPENSEARCH_HOST")

DELTA_INDEX = "npgw.transaction.delta"


def _build_delta_docs(old_img: dict, new_img: dict):
    """
    Build delta documents according to the scheme:
    - INSERT: +amount/+1 for the new status
    - MODIFY with status change: -amount/-1 for old status, +amount/+1 for new status
    """
    docs = []

    new_doc = custom_deserialize(new_img)
    old_doc = custom_deserialize(old_img) if old_img else {}

    transaction_id = new_doc.get("transactionId")
    merchant_id = new_doc.get("merchantId")
    currency = new_doc.get("currency")
    updated_on = new_doc.get("updatedOn")
    amount = int(new_doc.get("amount", 0) or 0)

    new_status = new_doc.get("status")
    old_status = old_doc.get("status")

    # INSERT: only positive delta for the initial status
    if not old_doc:
        docs.append({
            "_id": f"{transaction_id}-{updated_on}-{new_status}-plus",
            "body": {
                "transactionId": transaction_id,
                "merchantId": merchant_id,
                "currency": currency,
                "updatedOn": updated_on,
                "status": new_status,
                "amountChange": amount,
                "countChange": 1
            }
        })
        return docs

    # MODIFY: if status changed emit negative for old and positive for new
    if old_status != new_status:
        # negative delta for old status at the moment of change
        if old_status:
            docs.append({
                "_id": f"{transaction_id}-{updated_on}-{old_status}-minus",
                "body": {
                    "transactionId": transaction_id,
                    "merchantId": merchant_id,
                    "currency": currency,
                    "updatedOn": updated_on,
                    "status": old_status,
                    "amountChange": -amount,
                    "countChange": -1
                }
            })
        # positive delta for new status
        docs.append({
            "_id": f"{transaction_id}-{updated_on}-{new_status}-plus",
            "body": {
                "transactionId": transaction_id,
                "merchantId": merchant_id,
                "currency": currency,
                "updatedOn": updated_on,
                "status": new_status,
                "amountChange": amount,
                "countChange": 1
            }
        })

    return docs


def lambda_handler_delta(event, context):
    """
    Emit status delta documents per change into the delta index.
    """
    bulk_lines = []
    processed_records = 0

    for sns_record in event.get("Records", []):
        try:
            sns_message = json.loads(sns_record["Sns"]["Message"])
            dynamodb_event = sns_message.get("dynamodbEvent")
            if not dynamodb_event:
                continue

            event_name = dynamodb_event.get("eventName")
            dd = dynamodb_event.get("dynamodb", {})
            new_img = dd.get("NewImage", {})
            old_img = dd.get("OldImage", {})

            if event_name == "INSERT":
                docs = _build_delta_docs({}, new_img)
            elif event_name == "MODIFY":
                docs = _build_delta_docs(old_img, new_img)
            else:
                docs = []

            for d in docs:
                action_meta = {"index": {"_id": d["_id"]}}
                bulk_lines.append(json.dumps(action_meta))
                bulk_lines.append(json.dumps(d["body"]))

            processed_records += 1
        except Exception as e:
            print(f"Error processing SNS record: {e}")
            continue

    if not bulk_lines:
        return {"statusCode": 200}

    bulk_payload = "\n".join(bulk_lines) + "\n"

    try:
        make_bulk_request(
            OPENSEARCH_HOST,
            OPENSEARCH_USER,
            OPENSEARCH_PASSWORD,
            DELTA_INDEX,
            bulk_payload
        )
    except Exception as e:
        print(f"Bulk request to '{DELTA_INDEX}' failed: {e}")
        return {"statusCode": 500, "body": str(e)}

    return {"statusCode": 200}


