import json
import requests
import datetime
import os

from requests.auth import HTTPBasicAuth
from dotenv import load_dotenv

load_dotenv()


def custom_deserialize(item):
    """
    Recursively convert a DynamoDB item (with type annotations) into a plain Python object.

    Supported DynamoDB types:
      - S: String
      - N: Number (converted to int or float)
      - BOOL: Boolean
      - NULL: None
      - M: Map (dictionary)
      - L: List
      - SS: String Set (list of strings)
      - NS: Number Set (list of numbers)
      - BS: Binary Set (left as is)

    :param item: The DynamoDB item in its annotated JSON format.
    :return: A plain Python representation of the item.
    """
    if isinstance(item, dict):
        # Check if this dict is a DynamoDB type wrapper (single key that is one of the supported types)
        if len(item) == 1:
            key = next(iter(item))
            if key == "S":
                return item["S"]
            elif key == "N":
                num_str = item["N"]
                return int(float(num_str))
            elif key == "BOOL":
                return item["BOOL"]
            elif key == "NULL":
                return None
            elif key == "M":
                # recursively
                return {k: custom_deserialize(v) for k, v in item["M"].items()}
            elif key == "L":
                # recursively
                return [custom_deserialize(elem) for elem in item["L"]]
            elif key == "SS":
                # string set
                return item["SS"]
            elif key == "NS":
                numbers = []
                for num in item["NS"]:
                    numbers.append(int(float(num)))
                return numbers
            elif key == "BS":
                return item["BS"]
        return {k: custom_deserialize(v) for k, v in item.items()}
    elif isinstance(item, list):
        return [custom_deserialize(elem) for elem in item]
    else:
        #item is neither a dict nor a list.
        return item


def make_bulk_request(host, user, password, index, bulk_payload):
    """
    Send a bulk indexing request to OpenSearch.

    :param host: OpenSearch host
    :param user: OpenSearch user
    :param password: OpenSearch password
    :param index: The target OpenSearch index
    :param bulk_payload: The newline-delimited bulk JSON payload (ndjson)
    :return: parsed JSON response from OpenSearch
    """

    url = f"{host}/{index}/_bulk"
    headers = {"Content-Type": "application/json"}

    response = requests.post(
        url,
        data=bulk_payload,
        headers=headers,
        auth=HTTPBasicAuth(user, password),
        verify=False
    )
    response.raise_for_status()
    result = response.json()

    if result.get("errors"):
        print("Bulk indexing completed with errors:")
        for item in result.get("items", []):
            idx_action = item.get("index", {})
            if idx_action.get("error"):
                print(f" - ID {idx_action.get('_id')}: {idx_action.get('error')}")
    else:
        print(f"Bulk indexing successful: indexed {len(result.get('items', []))} documents.")

    return result


def process_dynamodb_record(record, doc_id_builder, update_on_nanoseconds):
    """
    Process a single DynamoDB record and return bulk lines if should be indexed.

    :param record: DynamoDB stream record
    :param doc_id_builder: Function(doc_dict) -> document ID string
    :param update_on_nanoseconds: Updated on timestamp converted to nanoseconds for versioning

    :return: List of bulk lines (action + document) or empty list if should skip
    """
    event_name = record.get("eventName")
    event_id   = record.get("eventID")
    dd         = record.get("dynamodb", {})

    new_img = dd.get("NewImage", {})
    old_img = dd.get("OldImage", {})

    if event_name == "INSERT":
        should_index = True
        reason = "INSERT"
    elif event_name == "MODIFY":
        old_status = custom_deserialize(old_img.get("status", {}))
        new_status = custom_deserialize(new_img.get("status", {}))
        status_changed = old_status != new_status

        old_operation_list = custom_deserialize(old_img.get("operationList", []))
        new_operation_list = custom_deserialize(new_img.get("operationList", []))
        operation_list_changed = old_operation_list != new_operation_list

        should_index = bool(status_changed or operation_list_changed)
        reason = (
            f"MODIFY; status_changed={status_changed}; "
            f"operationList_changed={operation_list_changed}"
        )
        if not should_index:
            print(f"Skipping MODIFY {event_id}: no relevant changes (status={new_status})")
    else:
        print(f"Ignoring {event_name} event {event_id}")
        return []

    if not should_index:
        return []

    doc = custom_deserialize(new_img)
    doc_id = doc_id_builder(doc)
    action_meta = {
        "index": {"_id": doc_id},
        "version_type": "external_gte",
        "version": update_on_nanoseconds
    }

    print(f"Indexing event {event_id}: {reason}")
    return [json.dumps(action_meta), json.dumps(doc)]


def base_lambda_handler(event, context, doc_id_builder, host, user, password, index):
    """
    Generic processor for SNS events containing DynamoDB stream events to bulk index documents.

    :param event: AWS Lambda SNS event
    :param context: AWS Lambda context
    :param doc_id_builder: Function(doc_dict) -> document ID string
    :param host: OpenSearch host
    :param user: OpenSearch user
    :param password: OpenSearch password
    :param index: OpenSearch index name

    :return: response dict
    """
    bulk_lines = []
    processed_records = 0

    for sns_record in event.get("Records", []):
        try:
            sns_message = json.loads(sns_record["Sns"]["Message"])
            transaction_id = sns_message.get("transactionId")
            dynamodb_event = sns_message.get("dynamodbEvent")
            update_on_nanoseconds = sns_message.get("update_on_nanoseconds")
            print(f"Processing SNS message for transaction: {transaction_id}")
            if not dynamodb_event:
                print("No DynamoDB event found in SNS message, skipping")
                continue
            bulk_lines.extend(process_dynamodb_record(dynamodb_event, doc_id_builder, update_on_nanoseconds))
            processed_records += 1
        except json.JSONDecodeError as e:
            print(f"Failed to parse SNS message {sns_record}: \n {e}")
            continue
        except KeyError as e:
            print(f"Missing expected field in SNS record {sns_record}: \n {e}")
            continue
        except Exception as e:
            print(f"Unexpected error processing SNS record {sns_record}: \n {e}")
            continue
        print(f"SUCCESS! event {transaction_id} will be indexed")

    print(f"Processed {processed_records} SNS records, generated {len(bulk_lines)//2} documents for indexing")

    if not bulk_lines:
        print("No documents to index.")
        return {"statusCode": 200}

    bulk_payload = "\n".join(bulk_lines) + "\n"

    try:
        make_bulk_request(
            host,
            user,
            password,
            index,
            bulk_payload
        )
    except Exception as e:
        print(f"Bulk request to '{index}' failed: {e}")
        return {"statusCode": 500, "body": str(e)}

    return {"statusCode": 200}


def iso_to_int(iso_timestamp):
    date_str, fractional = iso_timestamp.rstrip("Z").split(".")
    dt = datetime.datetime.fromisoformat(date_str).replace(tzinfo=datetime.timezone.utc)
    seconds = int(dt.timestamp())               # whole seconds
    nanoseconds = int(fractional)               # fractional nanoseconds
    total_ns = seconds * 1_000_000_000 + nanoseconds
    return total_ns


def _boto3_kwargs() -> dict:
    """Return extra boto3.client kwargs only when running in EE."""
    if os.getenv("ENVIRONMENT_TYPE") == "EE":
        return {
            "endpoint_url":          os.getenv("AWS_ENDPOINT_URL", "http://aws-mock:4566"),
            "region_name":           os.getenv("AWS_REGION", "eu-central-1"),
            "aws_access_key_id":     "test",
            "aws_secret_access_key": "test",
        }
    return {}